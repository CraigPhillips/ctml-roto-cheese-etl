{{
    name: "{0}",
    scores: new Array(
        {{
            category: "R",
            value: {1}
        }},
        {{
            category: "HR",
            value: {2}
        }},
        {{
            category: "RBI",
            value: {3}
        }},
        {{
            category: "SB",
            value: {4}
        }},
        {{
            category: "AVG",
            value: {5}
        }},
        {{
            category: "W",
            value: {6}
        }},
        {{
            category: "SV",
            value: {7}
        }},
        {{
            category: "K",
            value: {8}
        }},
        {{
            category: "ERA",
            value: {9}
        }},
        {{
            category: "WHIP",
            value: {10}
        }}
    )
}}