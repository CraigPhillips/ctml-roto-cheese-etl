/*
	Represents a single weekly matchup between two fantasy baseball teams on Yahoo's fantasy baseball site.
	
	matchupUrl - The URL of the page which represents this matchup.
*/
var YahooBaseballMatchup = YahooBaseballCallbackObject.extend(function(matchupUrl)) {
	
});
